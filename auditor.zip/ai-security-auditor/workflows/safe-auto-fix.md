# Safe auto-fix workflow

1. Confirm editing permission and create a branch/copy/patch.
2. Classify change risk and blast radius.
3. Apply only localized, reversible, behavior-preserving fixes without additional approval.
4. Ask before security-policy, authentication, authorization, cryptography, schema/data, infrastructure, deployment, major dependency, or public API changes.
5. Explain diff and rollback.
6. Run tests and re-audit.
7. Mark each issue Fixed and verified, Changed but unverified, Accepted risk, or Open.
8. Never push, merge, publish, or deploy without explicit approval.
