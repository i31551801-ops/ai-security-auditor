# Verification workflow

Re-run the specific test or scanner that identified the issue, then run relevant unit/integration/type/lint/build checks. Inspect the final diff for unintended changes and secrets. Compare to baseline. Record exact tool names, versions if known, commands, results, exclusions, and failures. Do not equate “no findings” with proof of security.
