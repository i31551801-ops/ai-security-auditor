# Full audit workflow

1. Intake and authorization.
2. Inventory files, stack, dependencies, entry points, and configuration.
3. Establish baseline and safe execution constraints.
4. Select specialist workstreams.
5. Run static, dependency, secret, and configuration analysis.
6. Perform dynamic checks only on explicitly authorized, non-production/staging or local targets with non-destructive scope.
7. Triage and deduplicate findings.
8. Prepare safe fixes; obtain approval for high-impact changes.
9. Run regression tests and repeat relevant security checks.
10. Produce report, changed-file list, residual risks, and next steps.
