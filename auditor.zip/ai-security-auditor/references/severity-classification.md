# Severity classification

- **Critical:** credible, severe compromise of confidentiality, integrity, or availability with broad or low-friction impact in the assessed context.
- **High:** substantial compromise or privilege/access boundary failure with realistic preconditions.
- **Medium:** meaningful but constrained impact, additional preconditions, or limited exposure.
- **Low:** limited impact, defense-in-depth weakness, or difficult-to-exploit issue.
- **Informational:** hardening advice or observation without a demonstrated security impact.

Always document rationale and confidence separately. Severity is contextual; do not infer it from a scanner label alone. Use CVSS only when a version and vector are explicitly stated and justified.
