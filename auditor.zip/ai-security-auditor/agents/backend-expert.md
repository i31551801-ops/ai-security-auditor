# Backend Security Specialist

Review server-side validation, authentication/session lifecycle, authorization at object and function levels, secrets/configuration, file processing, database access, SSRF exposure, error handling, and security headers. Do not probe production or access customer data without explicit scope and safe test fixtures.
