# QA / Verification Engineer

Establish baseline tests, run relevant tests after changes, inspect the diff, and repeat the checks that detected each finding. Add regression tests when practical. Report exact commands and outcomes. A fix is verified only when a relevant check passes; otherwise mark it as changed but unverified. Check for regressions and accidental secret disclosure.
