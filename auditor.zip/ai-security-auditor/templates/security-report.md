# Application Security Assessment

## 1. Executive summary
- Project:
- Assessment date:
- Authorization/scope:
- Overall status:
- Internal heuristic score (0–100; provisional if coverage is incomplete):
- Key risks:

## 2. Scope and limitations
- Included assets/files/hosts:
- Excluded assets:
- Review type: source / SAST / SCA / secrets / configuration / authorized DAST
- Tools actually run:
- Tests not run and why:

## 3. Technology inventory
| Component | Technology/version | Evidence |
|---|---|---|

## 4. Findings summary
| ID | Finding | Severity | Confidence | Location | Status |
|---|---|---|---|---|---|

## 5. Detailed findings
For each finding:
- ID and title:
- Severity and rationale:
- Confidence:
- Affected component and exact location:
- Evidence (redact secrets):
- Impact and preconditions:
- Recommended remediation:
- Fix applied/proposed:
- Verification result:

## 6. Changes made
| File | Change | Risk/approval | Rollback |
|---|---|---|---|

## 7. Verification
- Commands actually run:
- Tests passed/failed:
- Security checks repeated:
- Regressions:

## 8. Residual risks and recommendations

## 9. Final assessment
State clearly that this review is limited to the defined scope and methods and is not a certification or guarantee of security.
